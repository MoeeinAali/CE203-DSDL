// LIFO stack — pure behavioural description (always blocks only).
//
// Geometry (defaults match the lab spec): DEPTH=8 words of WIDTH=4 bits.
//
// Interface contract
// ------------------
//   Clk    : rising-edge clock; every state change happens here.
//   RstN   : asynchronous, ACTIVE-LOW reset. Empties the stack.
//   Push   : request to write Data_In on top of the stack.
//   Pop    : request to remove the top word.
//   Data_In: word to be pushed.
//   Data_Out: word currently on top (combinational read of the top cell).
//             Held at 0 while the stack is empty.
//   Full   : 1 when the stack holds DEPTH words (a Push is then ignored).
//   Empty  : 1 when the stack holds no words (a Pop is then ignored).
//
// Command arbitration
// -------------------
//   Push & Pop asserted together is a no-op (replace-top is deliberately NOT
//   implemented: the lab specifies two independent commands, so the safe
//   reading is that a contradictory request changes nothing).
//   Push when Full and Pop when Empty are ignored — the stack never
//   overflows into or underflows out of its storage.
//
// Storage model
// -------------
//   `sp` is the stack pointer = number of valid words, so it needs one extra
//   bit to represent the value DEPTH itself. The topmost valid word lives at
//   mem[sp-1]; the next Push writes to mem[sp].
module stack #(
    parameter integer WIDTH = 4,
    parameter integer DEPTH = 8
) (
    input  wire                  Clk,
    input  wire                  RstN,
    input  wire [WIDTH-1:0]      Data_In,
    input  wire                  Push,
    input  wire                  Pop,
    output reg  [WIDTH-1:0]      Data_Out,
    output wire                  Full,
    output wire                  Empty
);
    // Pointer width: must hold 0..DEPTH inclusive.
    localparam integer PTR_W = $clog2(DEPTH) + 1;

    reg [WIDTH-1:0] mem [0:DEPTH-1];
    reg [PTR_W-1:0] sp;                  // number of words currently stored

    integer i;

    assign Empty = (sp == 0);
    assign Full  = (sp == DEPTH[PTR_W-1:0]);

    // Effective commands after arbitration.
    wire do_push = Push & ~Pop & ~Full;
    wire do_pop  = Pop  & ~Push & ~Empty;

    // ---- state: stack pointer + memory -------------------------------
    always @(posedge Clk or negedge RstN) begin
        if (!RstN) begin
            sp <= {PTR_W{1'b0}};
            for (i = 0; i < DEPTH; i = i + 1)
                mem[i] <= {WIDTH{1'b0}};
        end else begin
            if (do_push) begin
                mem[sp] <= Data_In;
                sp      <= sp + 1'b1;
            end else if (do_pop) begin
                sp <= sp - 1'b1;
            end
        end
    end

    // ---- output: combinational view of the top word -------------------
    // Written behaviourally (always @*) rather than with assign, to keep the
    // whole module in the behavioural style the lab asks for.
    always @(*) begin
        if (sp == 0)
            Data_Out = {WIDTH{1'b0}};
        else
            Data_Out = mem[sp - 1'b1];
    end
endmodule
