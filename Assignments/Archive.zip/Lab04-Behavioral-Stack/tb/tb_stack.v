`timescale 1ns/1ps

// Self-checking testbench for the behavioural stack.
// Strategy: keep an independent golden model (a plain Verilog array + count)
// beside the DUT, drive both from the same stimulus, and compare
// Data_Out/Full/Empty after every clock edge.
module tb_stack;
    localparam integer WIDTH = 4;
    localparam integer DEPTH = 8;

    reg                  Clk, RstN, Push, Pop;
    reg  [WIDTH-1:0]     Data_In;
    wire [WIDTH-1:0]     Data_Out;
    wire                 Full, Empty;

    stack #(.WIDTH(WIDTH), .DEPTH(DEPTH)) dut (
        .Clk(Clk), .RstN(RstN), .Data_In(Data_In),
        .Push(Push), .Pop(Pop),
        .Data_Out(Data_Out), .Full(Full), .Empty(Empty)
    );

    // ---------------- golden reference model ----------------
    reg [WIDTH-1:0] ref_mem [0:DEPTH-1];
    integer         ref_sp;

    integer pass, fail;
    integer i, k, iter;
    reg [WIDTH-1:0] exp_dout;
    reg             exp_full, exp_empty;

    // 10 ns period; all stimulus is applied on the falling edge so that
    // setup/hold around the rising edge is never ambiguous.
    initial Clk = 1'b0;
    always #5 Clk = ~Clk;

    // ---------------- helpers ----------------
    task automatic ref_reset;
        begin
            ref_sp = 0;
            for (i = 0; i < DEPTH; i = i + 1) ref_mem[i] = {WIDTH{1'b0}};
        end
    endtask

    // Apply one clock cycle with the given command and update the model.
    task automatic step;
        input               p_push;
        input               p_pop;
        input [WIDTH-1:0]   p_din;
        input [255:0]       tag;
        begin
            @(negedge Clk);
            Push    = p_push;
            Pop     = p_pop;
            Data_In = p_din;

            // Model the same arbitration the DUT uses.
            @(posedge Clk);
            if (p_push && !p_pop && ref_sp < DEPTH) begin
                ref_mem[ref_sp] = p_din;
                ref_sp          = ref_sp + 1;
            end else if (p_pop && !p_push && ref_sp > 0) begin
                ref_sp = ref_sp - 1;
            end

            #1;                       // let combinational outputs settle
            check(tag);
        end
    endtask

    task automatic check;
        input [255:0] tag;
        begin
            exp_empty = (ref_sp == 0);
            exp_full  = (ref_sp == DEPTH);
            exp_dout  = (ref_sp == 0) ? {WIDTH{1'b0}} : ref_mem[ref_sp-1];

            if (Data_Out === exp_dout && Full === exp_full && Empty === exp_empty) begin
                pass = pass + 1;
            end else begin
                $display("FAIL [%0s] sp=%0d  got D=%h F=%b E=%b   exp D=%h F=%b E=%b",
                         tag, ref_sp, Data_Out, Full, Empty,
                         exp_dout, exp_full, exp_empty);
                fail = fail + 1;
            end
        end
    endtask

    task automatic do_reset;
        begin
            @(negedge Clk);
            Push = 0; Pop = 0; Data_In = 0;
            RstN = 1'b0;
            @(negedge Clk);
            RstN = 1'b1;
            ref_reset;
            #1;
            check("reset");
        end
    endtask

    // ---------------- stimulus ----------------
    initial begin
        pass = 0; fail = 0;
        RstN = 1'b1; Push = 0; Pop = 0; Data_In = 0;
        ref_reset;

        // 1) Asynchronous reset brings up an empty stack.
        do_reset;

        // 2) Pop on an empty stack is ignored (underflow protection).
        step(1'b0, 1'b1, 4'h0, "pop_when_empty_1");
        step(1'b0, 1'b1, 4'h0, "pop_when_empty_2");

        // 3) Fill the stack completely: 1,2,...,8. Full must rise exactly
        //    on the 8th push, and not before.
        for (k = 0; k < DEPTH; k = k + 1)
            step(1'b1, 1'b0, k[WIDTH-1:0] + 4'h1, "fill");

        // 4) Push on a full stack is ignored (overflow protection):
        //    Data_Out must stay at the last pushed word.
        step(1'b1, 1'b0, 4'hF, "push_when_full_1");
        step(1'b1, 1'b0, 4'hE, "push_when_full_2");

        // 5) Drain completely — LIFO order 8,7,...,1.
        for (k = 0; k < DEPTH; k = k + 1)
            step(1'b0, 1'b1, 4'h0, "drain");

        // 6) Idle cycles change nothing.
        step(1'b0, 1'b0, 4'h5, "idle_empty");

        // 7) Push+Pop together is a no-op, at empty / mid / full depth.
        step(1'b1, 1'b1, 4'hA, "both_at_empty");
        step(1'b1, 1'b0, 4'h3, "seed_mid");
        step(1'b1, 1'b0, 4'h7, "seed_mid");
        step(1'b1, 1'b1, 4'hC, "both_at_mid");
        step(1'b0, 1'b0, 4'h0, "idle_mid");
        for (k = 0; k < DEPTH; k = k + 1)
            step(1'b1, 1'b0, 4'h9, "refill");
        step(1'b1, 1'b1, 4'hB, "both_at_full");

        // 8) Asynchronous reset from a non-empty state clears everything.
        do_reset;

        // 9) Interleaved push/pop — the classic LIFO order check.
        step(1'b1, 1'b0, 4'h1, "int_push1");
        step(1'b1, 1'b0, 4'h2, "int_push2");
        step(1'b0, 1'b1, 4'h0, "int_pop2");   // top must fall back to 1
        step(1'b1, 1'b0, 4'h3, "int_push3");
        step(1'b1, 1'b0, 4'h4, "int_push4");
        step(1'b0, 1'b1, 4'h0, "int_pop4");
        step(1'b0, 1'b1, 4'h0, "int_pop3");
        step(1'b0, 1'b1, 4'h0, "int_pop1");   // empty again

        // 10) Randomised stress: 2000 random commands against the model.
        do_reset;
        for (iter = 0; iter < 2000; iter = iter + 1)
            step($random, $random, $random, "random");

        $display("tb_stack: Passed: %0d, Failed: %0d", pass, fail);
        if (fail != 0) $fatal(1);
        $finish;
    end

    // Safety net: never let a broken DUT hang the run.
    initial begin
        #500000;
        $display("FAIL: timeout");
        $fatal(1);
    end
endmodule
